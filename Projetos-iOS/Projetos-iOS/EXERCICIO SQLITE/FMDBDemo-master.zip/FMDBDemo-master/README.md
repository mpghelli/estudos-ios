# A Simple Demo app for FMDB

We’ll take our walk through the FMDB library by using some simple examples in a small demonstrative app we’ll implement next. We’ll start by creating a new database programmatically, and we’ll see all the usual operations that can apply to the data: Insert, update, delete and select.

For the full tutorial, you can take a look at the link below:

http://www.appcoda.com/fmdb-sqlite-database/
